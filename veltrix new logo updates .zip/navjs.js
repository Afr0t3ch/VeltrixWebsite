
 document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.querySelector('.menu-toggle');
    const nav = document.getElementById('navMenu');

    menuToggle.addEventListener('click', function () {
      nav.classList.toggle('show');
    });
  });
